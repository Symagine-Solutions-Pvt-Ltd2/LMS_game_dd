
// holding the cards 

export default function Box(props) { 
    return (
      <div id={props.id} className={props.className}>
        {props.children}
      </div>
    );
  }
  