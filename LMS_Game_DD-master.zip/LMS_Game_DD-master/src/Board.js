import Apple from "./images/Apple.png";
import Banana from "./images/Banana.png";
import Band_Aid from "./images/Band_Aid.png";
import Bottle_1 from "./images/Bottle_1.png";
import Bottle2 from "./images/Bottle2.png";
import Brokenglass from "./images/Brokenglass.png";
import Cardboardbox from "./images/Cardboardbox.png";
import Eggshell from "./images/Eggshell.png";
import Old_News_papers from "./images/Old_News_papers.png";
import Plasticbag from "./images/Plasticbag.png";
import Plasticstraw from "./images/Plasticstraw.png";
import  Sanitarynapkin from "./images/Sanitarynapkin.png";

import Option from "./Option";


//  shows  options one by one using  map 
export default function Board(props) {

    const pic = [
        { id: "c1", src: Apple  , name: "Apple" },
        { id: "c1", src: Banana, name: "Banana" },
        { id: "c2", src: Band_Aid, name: "Band Aid" },
        { id: "c3", src: Bottle_1, name: "Bottle" },
        { id: "c3", src: Bottle2, name: "Bottle2" } , 
        { id: "c4", src: Brokenglass, name: "Broken glass" },
        { id: "c4", src: Cardboardbox, name: "Card board box" },
        { id: "c1", src: Eggshell, name: "Eggshell" },
        { id: "c4", src: Old_News_papers, name: "Old News papers" },
        { id: "c3", src: Plasticbag, name: "Plasticbag" },
        { id: "c3", src: Plasticstraw, name: "Plastic cup straw" },
        { id: "c2", src: Sanitarynapkin , name: "Sanitary napkin" }

      ];
    
    return (
      <div id={props.id} className="board" empty={props.empty}>
          {pic.map((p) => (
        <Option id={p.id} className="option" img={p.src} name={p.name} />
      ))}
      </div>
    );
  }
  