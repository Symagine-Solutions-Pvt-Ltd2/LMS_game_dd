import { useState } from "react";

export default function Card(props) {  //  in cards the  right options are to be dropped (  rendered in box  )
  const [srcc, setSrcc] = useState(props.icon);  // for maintaining  img src state  of cards 
  const card_id = props.id;

  const drop = (e) => {

    e.preventDefault();

   

    const option_id = e.dataTransfer.getData("option_id");  // to get the option id to check if it is dropable 
    const par_id = e.dataTransfer.getData("par");
    const img_src = e.dataTransfer.getData("img_src");  // get the img url to update  if drop is succesfull

    const option = document.getElementById(option_id);

    
    if (option.id === card_id) {   // main logic to check  if drop is possible ( in cards )  otherwise revert the options 
      e.target.appendChild(option);  
      setSrcc(img_src);
      option.style.display = "none";

      
    } 

  }; // for drag and drop

  const dragOver = (e) => {
    e.preventDefault();
  };

  return (
    <div id={props.id} className="imm" onDrop={drop} onDragOver={dragOver}>
      <img
        draggable="false"
        id="f1"
        className="icon"
        src={srcc}
        height="80px"
        alt="icon"
      />
      <p>{props.text}</p>
    </div>
  );
}
