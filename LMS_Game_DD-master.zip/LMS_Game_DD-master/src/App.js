
import "./styles.css";
import Box from "./Box";
import Board from "./Board";
import Card from "./Card";
import BWG from "./images/BWG.png";
import  SW from "./images/SW.png";
import PW from "./images/PW.png";
import ORW from "./images/ORW.png";

function App() {
  return (
    <div className="app">
       <div className="flexbox">
        <Board id="b1" className="board" empty="true" />

        <Box id="box1" className="box">
        
          <Card id="c1" icon={BWG} text="Biodegradable Waste" />
          <Card id="c2" icon={SW} text="Sanitary Waste" />
          <Card id="c3" icon={PW} text="Plastic Waste" />
          <Card id="c4" icon={ORW} text="Other Recyclable Waste" />
        </Box>
      </div>
      
    </div>
  );
}

export default App;
