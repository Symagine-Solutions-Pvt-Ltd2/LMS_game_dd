//   dragged and dropped into the  right cards to match ( rendered in the board )

export default function Option(props) {  // 
    const dragStart = (e) => {
      const target = e.target;    //  target is the option itself 
  
      const target1 = e.target.parentNode;
  
      const img_src = target.childNodes[0].src;
      
     // set the data  so that during drop card can get the data 
      e.dataTransfer.setData("option_id", target.id);
      e.dataTransfer.setData("par", target1.id);
      e.dataTransfer.setData("img_src", img_src);    // img url of the option to update card img  during drop 
  
      setTimeout(() => {
        target.style.opacity = 0;
      }, 0);
    };
  
    const dragEnd = (e) => {
      const target = e.target;
      target.style.opacity = 1;
    };
  
    const dragOver = (e) => {
      e.stopPropagation();
    };
  
    return (
      <div
        id={props.id}
        className="imm"
        draggable="true"
        onDragStart={dragStart}
        onDragEnd={dragEnd}
        onDragOver={dragOver}
      >
        <img
          draggable="false"
          id="f1"
          className="icon"
          src={props.img}
          height="80px"
          alt="icon"
        />
        <p>{props.name}</p>
      </div>
    );
  }
  